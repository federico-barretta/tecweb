function validateLogin() {
    const email = $('#email').val()
    const password = $('#psw').val()
    const url = "http://127.0.0.1:10000";


    const xhttpr = new XMLHttpRequest();
    xhttpr.open('POST', url+'/login', true);

    xhttpr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttpr.send(JSON.stringify({"email": email, "password": password}));

    xhttpr.onload = () => {
        if (xhttpr.status === 200) {
            const response = xhttpr.response
            if (response !== "0") {

                window.location.replace("http://localhost:8000/front-end/home.html")

            } else {
                alert("Credenziali Errate")
            }
        } else {
            // Handle error
        }
    };
}