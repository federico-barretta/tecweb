function register() {
    const windowHeight = window.innerHeight;
const windowWidth = window.innerWidth;

    const email = $('#email').val()
    const password = $('#psw').val()
    const nome = $('#nome').val()
    const cognome = $('#cognome').val()
    const dn = $('#dn').val()

    const url = "http://127.0.0.1:10000";



    const xhttpr = new XMLHttpRequest();
    xhttpr.open('POST', url+'/register', true);

    xhttpr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttpr.send(JSON.stringify({"email": email, "password": password, "nome": nome, "cognome": cognome, "datanascita": dn}));

    xhttpr.onload = () => {
        if (xhttpr.status === 200) {
            const response = xhttpr.response
            console.log(response)
            if (response === "OK") {
                alert("Registrazione effettuata con successo, Buon Viaggio")
                window.location.replace("http://localhost:8000/front-end/home.html")

            } else {
                alert("Errore Durante La registrazione, probabilmente l' email è stata gia inserita")
            }
        } else {
            // Handle error
        }
    };
}