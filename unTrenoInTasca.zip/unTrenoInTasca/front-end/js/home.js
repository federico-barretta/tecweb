$(document).ready(function () {

    $($('#tabella')[0]).hide();
    $($('#tabellaScali')[0]).hide()
    filldatalist();

    console.log("Caricamento completato")


    //vediscali('[{"arrivalTime":"2024-05-18T06:08:00.000+02:00","departureTime":"2024-05-18T06:02:00.000+02:00","destination":"Cancello","id":"xd1b1818a-0199-4135-a72c-e45281be5a18","origin":"Acerra","salable":false,"train":{"acronym":"RE","denomination":"label.train.info.denomination.re","description":"5774","logoId":"RE","name":"5774","trainCategory":"Regionale","urban":false}},{"arrivalTime":"2024-05-18T07:16:00.000+02:00","departureTime":"2024-05-18T06:31:00.000+02:00","destination":"Salerno","id":"x16f4be6c-6e84-4992-99a6-35edb86881a7","origin":"Cancello","salable":false,"train":{"acronym":"RE","denomination":"label.train.info.denomination.re","description":"4897","logoId":"RE","name":"4897","trainCategory":"Regionale","urban":false}},{"arrivalTime":"2024-05-18T07:56:00.000+02:00","departureTime":"2024-05-18T07:33:00.000+02:00","destination":"Acquamela","id":"xfd23fb61-b0c2-4aa4-9989-345490f8e356","origin":"Salerno","salable":false,"train":{"acronym":"RE","denomination":"label.train.info.denomination.re","description":"5010","logoId":"RE","name":"5010","trainCategory":"Regionale","urban":false}}]')

});

$(window).load(function () {
    console.log("Caricamento In Corso")
});

function filldatalist() {
    const xhttpr = new XMLHttpRequest();
    const url = "http://127.0.0.1:10000";
    xhttpr.open('GET', url + '/filldatalist', true);
    xhttpr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttpr.send()
    xhttpr.onload = () => {
        if (xhttpr.status === 200) {
            const response = xhttpr.response
            if (response !== "0") { //Se la richiesta è andata a bion fine

                const parsed = JSON.parse(response)


                let par = $("#partenze")[0]
                let dest = $("#destinazioni")[0]

                par.innerHTML = "";
                dest.innerHTML = "";

                let newline = ""
                for (let i = 0; i < parsed.length - 1; i++) {
                    newline = "<option>";
                    newline += parsed[i];
                    newline += "</option>";

                    par.innerHTML += newline;
                    dest.innerHTML += newline;

                }


            } else {

            }
        } else {
            console.log("Impossibile raggiungere il server")
        }
    }


}

function estraiora(timestamp) {

    timestamp = timestamp.split(" ")
    return timestamp[1]
}


function convertiTimestamp(timestampString) { // le date in javascript sono molto simpatiche

    var data = new Date(timestampString);


    var giorno = data.getDate();
    var mese = data.getMonth() + 1;
    var anno = data.getFullYear();
    var ora = data.getHours();
    var minuto = data.getMinutes();
    var secondo = data.getSeconds();

    if (giorno < 10) {
        giorno = '0' + giorno;
    }
    if (mese < 10) {
        mese = '0' + mese;
    }
    if (ora < 10) {
        ora = '0' + ora;
    }
    if (minuto < 10) {
        minuto = '0' + minuto;
    }
    if (secondo < 10) {
        secondo = '0' + secondo;
    }


    return `${giorno}/${mese}/${anno} ${ora}:${minuto}:${secondo}`;
}

function searchOptions() {
    console.log("Cerco le Opzioni")
    //new DataTable('#solutions');
    $($('#tabella')[0]).show();
    const xhttpr = new XMLHttpRequest();
    const url = "http://127.0.0.1:10000";
    const body = $("#body")[0]; //prendi l' elemento
    body.innerHTML = ""; //Azzeda i dati della tabella
    xhttpr.open('POST', url + '/searchOptions', true);
    xhttpr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    xhttpr.send(JSON.stringify({ //invia dati al backand
        "from": $('#partenza')[0].value,
        "to": $('#destinazione')[0].value,
        "adulti": $('#adulti')[0].value,
        "bambini": $('#bambini')[0].value,
        "time": $('#when')[0].value
    }))
    xhttpr.onload = () => {
        if (xhttpr.status === 200) {
            const response = xhttpr.response;
            if (response !== "0") {
                let parsed = JSON.parse(response)
                let solutions = parsed.solutions


                $("#title")[0].innerHTML = "Soluzioni " + $('#partenza')[0].value + " -> " + $('#destinazione')[0].value;

                if (typeof solutions === "undefined") {
                    alert("Nessuna soluzione individuata")
                } else {

                    for (let i = 0; i < solutions.length; i++) {
                        let newline = "<tr>";

                        newline += "<td>" + convertiTimestamp(solutions[i].solution.departureTime) + "</td>"; //data ora partenza
                        newline += "<td>" + convertiTimestamp(solutions[i].solution.arrivalTime) + "</td>"; //data ora arrivo
                        newline += "<td>" + solutions[i].solution.duration + "</td>"; //data ora arrivo
                        newline += "<td>" + solutions[i].solution.nodes.length + "</td>"; //numero scali
                        newline += "<td>" + solutions[i].solution.price.currency + solutions[i].solution.price.amount + "</td>"; //Prezzo

                        if (solutions[i].solution.nodes.length > 1) {
                            newline += "<td><button class = 'btn btn-primary' onclick='vediscali(`" + JSON.stringify(solutions[i].solution.nodes) + "`)'>Vedi Scali</button></td>"; //Azione
                        } else {
                            newline += "<td></td>"
                        }


                        newline += "<td><button id='payment_options'  class = 'btn btn-success' onclick='prenota()'>prenota</td>"; //Azione
                        newline += "</tr>";
                        body.innerHTML += newline
                    }
                }


            } else {
                alert("Nessuna Offerta trovata")
            }
        } else {
            console.log("Impossibile raggiungere il server")
        }
    }
}

function prenota() {
 alert("La prenotazione ha avuto buon fine puoi effettuare una nuova prenotazione");
}

function vediscali(scali) {
    let parsed = JSON.parse(scali)

    let tab = $('#tabellaScali')[0]

    $($('#tabellaScali')[0]).show()
    $($('#tabella')[0]).hide()
    console.log(parsed)

    tab.innerHTML = " <h1 id=\"titleScali\">Scali</h1>\n" +
        "   \n" +
        "\n" +
        "    <button type=\"button\" class=\"btn btn-danger\" data-dismiss=\"modal\" onclick=\"$($('#tabellaScali')[0]).hide(); $($('#tabella')[0]).show()\">Chiudi\n" +
        "    </button>"

    for (let i = 0; i < parsed.length; i++) {
        let newline = '<div> arrivo presso: ' + parsed[i].destination + " Alle " + estraiora(convertiTimestamp(parsed[i].arrivalTime)) + '</div>';
        console.log(newline)
        if (i !== parsed.length - 1) {
            newline += "<div><img height='50px' src='img/arrow.png'></div>"
        }
        tab.innerHTML += newline

    }


}

function swap() {
    const app = $("#partenza")[0].value;
    $("#partenza")[0].value = $("#destinazione")[0].value;
    $("#destinazione")[0].value = app
}





