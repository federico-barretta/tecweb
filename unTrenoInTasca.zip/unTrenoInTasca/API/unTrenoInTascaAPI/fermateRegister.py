import pandas as pd
import sqlite3

con = sqlite3.connect("DB/db.sqlite") #Connetti al DB
cur = con.cursor()

file = pd.read_excel('fermate.xlsx', header=0)  # leggi il file excel dall' inizio
iterator = file.itertuples()  # Iteratore

"""
Indici:

0 = Indice
1 = Stazione
2 = Indirizzo
3 = Comune
4 = Provincia
"""
for row in iterator:  # per ogni riga

    row = list(row)  # Trasfiormo in unalista perchè le tuple non si possono modificare
    for i in range(5):
        row[i] = str(row[i]).replace("'", "")  # Tolgo gli apici che danno errori di sintassi

    res = cur.execute(f"select * from stazione where nome = '{row[1]}'") #Vedi se la stazione si trova nel DB
    res = res.fetchall()

    if len(res) == 0:  # Se non è stato ancora inserito
        cur.execute(f"insert into stazione values('{row[1]}','{row[2]}','{row[3]}','{row[4]}')") #Inserisci nel DB

cur.execute(f"update stazione set provincia = 'NA' where provincia = 'nan'")  # per qualche motivo NA lo legge nan

con.commit()  # Applica le modifiche
con.close()  # Chiudi la connessione
