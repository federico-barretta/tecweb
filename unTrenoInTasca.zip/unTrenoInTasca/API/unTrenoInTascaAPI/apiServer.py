import sqlite3
from flask import Flask, request, jsonify, session
from flask_cors import CORS
import requests
import json

api_port = 10000
api_host = '127.0.0.1'  # localhost
app = Flask(__name__)
CORS(app, resources={r'*': {'origins': '*'}})

db = sqlite3.connect('DB/db.sqlite', check_same_thread=False)  # connect db
cursor = db.cursor()

app.secret_key = 'UN_TRENO_IN_TASCA'


def nametoid(station):
    request_data = requests.get(
        f"https://www.lefrecce.it/Channels.Website.BFF.WEB/website/locations/search?limit=1&name={station}")
    data = request_data.json()
    try:
        return data[0]["id"]
    except IndexError as e:
        return 0


@app.route('/searchOptions', methods=['post'])
def searchoptions():
    data = request.get_json()
    start = nametoid(data["from"])
    end = nametoid(data["to"])

    if not start or not end:

        return jsonify({})

    time = data["time"] + ":00.000+02:00"

    payload = {
        "departureLocationId": start,
        "arrivalLocationId": end,
        "departureTime": time,
        "adults": data["adulti"],
        "children": data["bambini"],
        "criteria": {
            "frecceOnly": False,
            "regionalOnly": False,
            "noChanges": False,
            "order": "DEPARTURE_DATE",
            "limit": 10,
            "offset": 0
        },
        "advancedSearchRequest": {
            "bestFare": False
        }
    }

    payload = json.dumps(payload)

    solutions = requests.post("https://www.lefrecce.it/Channels.Website.BFF.WEB/website/ticket/solutions",
                              headers={'Content-type': 'application/json'}, data=payload)

    return solutions.json()


@app.route('/login', methods=['POST'])
def loginendpoint():
    data = request.get_json()  # Get JSON data from the request

    # Check if the user is an operator
    sql = f"select * from utente o where o.email = '{data['email']}' and o.password = '{data['password']}'"
    cursor.execute(sql)
    rows = cursor.fetchone()
    db.commit()

    session['user'] = rows[0]

    if len(rows) > 0:
        return "OK"
    else:
        return "0"


@app.route('/filldatalist', methods=['get'])
def filldatalist():
    cursor.execute("select nome from stazione order by nome")
    rows = cursor.fetchall()
    return jsonify(rows)


@app.route('/register', methods=['post'])
def register():
    user_data = request.get_json()
    cursor.execute(f"select * from utente where email = '{user_data['email']}'")
    rows = cursor.fetchall()

    if len(rows) == 0:
        cursor.execute(
            f"insert into utente(nome,cognome,datanascita,email,password) values ('{user_data['nome']}', '{user_data['cognome']}','{user_data['datanascita']}', '{user_data['email']}','{user_data['password']}')")
        db.commit()

        return "OK"
    else:
        return "Error"




def api_server(debug, host, port):
    app.run(debug=debug, host=host, port=port)
